// Sample records matching the supplied screenshots. The second screenshot did
// not provide an email address or registration time for Clyde.
export const INITIAL_STUDENTS = [
  {
    id: '2023-0190',
    fullName: 'PETHUEL J. PRADO',
    studentId: '2023-0190',
    email: 'pethuelprado0@gmail.com',
    course: 'BS Information Technology',
    yearLevel: '4th Year',
    subjects: ['SIA102', 'CAP101', 'IAS102', 'WST101', 'SAM101', 'ANI102'],
    // September 28, 2026, 11:54 PM in the Philippines (UTC+08:00).
    registeredAt: '2026-09-28T23:54:00+08:00',
  },
  {
    id: '2023-0191',
    fullName: 'CLYDE TIUC',
    studentId: '2023-0191',
    email: '',
    course: 'BS Information Technology',
    yearLevel: '4th Year',
    subjects: [],
    registeredAt: null,
  },
]
